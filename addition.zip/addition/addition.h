/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_addition__
#define __USER_CODE_H_addition__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void addition_startup();

void addition_PI_numbers(const asn1SccT_Int8 *,
                         const asn1SccT_Int8 *);

extern void addition_RI_sum(const asn1SccT_Int8 *);

#ifdef __cplusplus
}
#endif


#endif
